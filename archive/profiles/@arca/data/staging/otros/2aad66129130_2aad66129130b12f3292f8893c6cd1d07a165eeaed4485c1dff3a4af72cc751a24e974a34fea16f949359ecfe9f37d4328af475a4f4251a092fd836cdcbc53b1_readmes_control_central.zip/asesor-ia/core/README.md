# 📁 core/ – Núcleo Técnico del Asesor-IA

Esta carpeta aloja los módulos técnicos que utiliza el asesor-IA dentro de `control_central`. Está dividida en tres partes:

- `notebooks/`: Documentos interactivos para pruebas técnicas, análisis o exploración IA.
- `scripts/`: Scripts reutilizables para tareas de automatización, formateo, ingestión u otros procesos clave.
- `tests/`: Casos de prueba funcionales para validar cada script o módulo desarrollado.

✅ Toda modificación en esta carpeta debe ser trazada con bitácora y changelog.
