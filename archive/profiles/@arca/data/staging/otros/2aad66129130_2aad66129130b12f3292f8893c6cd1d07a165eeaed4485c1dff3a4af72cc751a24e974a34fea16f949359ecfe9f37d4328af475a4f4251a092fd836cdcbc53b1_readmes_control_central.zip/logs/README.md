# 📁 logs/ – Registro de Actividades del Sistema

Este módulo contiene todos los logs del sistema clasificados por tipo:

- `auditorias/`: Registros generados por revisiones técnicas.
- `bakcup_git/`: Salida del script `backup_to_git.sh`.
- `logs_historicos/`: Logs antiguos ya revisados.
- `status_alma/`: Estado general de ALMA_RESIST.
- `status_sync/`: Verificación de sincronización entre nodos.

🔁 Estos logs se actualizan automáticamente y están pensados para ser leídos por CLI o IA.
