# 📁 status/ – Indicadores de Estado del Sistema

Carpeta que contiene archivos JSON o YAML con el estado actual del sistema, nodos y sincronización.

- Permite consultas automatizadas por CLI o dashboards.
- Es actualizada por scripts internos.

💡 Puede ser referenciada por comandos como `alma status`.
