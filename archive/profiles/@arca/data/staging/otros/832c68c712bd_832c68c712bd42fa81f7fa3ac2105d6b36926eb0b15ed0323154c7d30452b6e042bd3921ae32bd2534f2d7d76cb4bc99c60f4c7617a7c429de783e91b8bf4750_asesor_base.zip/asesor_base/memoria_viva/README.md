Backups o extractos históricos de memoria viva (YAML), o snapshots de estado.
Puede ser útil para auditar cambios o reconstruir historia.
