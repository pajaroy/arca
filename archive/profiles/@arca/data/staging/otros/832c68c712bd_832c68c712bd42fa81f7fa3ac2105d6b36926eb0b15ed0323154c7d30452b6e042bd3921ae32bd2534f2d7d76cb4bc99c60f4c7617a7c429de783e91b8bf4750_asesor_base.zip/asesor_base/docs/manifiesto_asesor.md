# Manifiesto del Asesor

Resumen filosófico y de misión de este asesor IA.
