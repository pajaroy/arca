Bitácoras y logs manuales del asesor.
Aquí se guardan auditorías, registros de reuniones, decisiones puntuales, o incidencias detectadas.
