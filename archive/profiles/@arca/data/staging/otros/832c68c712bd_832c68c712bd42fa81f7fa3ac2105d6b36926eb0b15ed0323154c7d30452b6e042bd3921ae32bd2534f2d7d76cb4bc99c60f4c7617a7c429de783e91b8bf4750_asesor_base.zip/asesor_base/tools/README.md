Herramientas, scripts y utilidades relacionadas al asesor.
Desde scripts de parsing hasta helpers de validación YAML.
