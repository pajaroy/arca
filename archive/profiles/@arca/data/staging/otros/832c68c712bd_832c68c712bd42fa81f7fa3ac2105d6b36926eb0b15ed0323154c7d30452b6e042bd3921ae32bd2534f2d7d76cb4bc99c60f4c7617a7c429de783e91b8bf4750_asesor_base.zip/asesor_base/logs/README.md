Logs automáticos, errores técnicos, auditorías periódicas generadas por sistemas o scripts.
