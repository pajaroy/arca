# Prompt base del asesor

[Colocá aquí el prompt inicial y plantillas clave.]
