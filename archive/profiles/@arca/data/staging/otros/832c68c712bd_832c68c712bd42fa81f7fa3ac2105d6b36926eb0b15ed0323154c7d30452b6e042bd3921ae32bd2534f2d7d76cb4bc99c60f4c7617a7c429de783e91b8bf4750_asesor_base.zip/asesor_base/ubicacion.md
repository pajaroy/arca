Este asesor está alojado en:
Ruta: /ALMA_RESIST/control_central/asesor-ia/[asesor]/
Última versión: [vX.X]
Fecha de última actualización: [YYYY-MM-DD]
Responsable: [nombre]
Notas: Actualizar en cada migración física o de sistema.
