Documentación y manifiestos institucionales.
Incluye manifiesto del asesor, protocolos, acuerdos, o textos base que definan filosofía y límites.
