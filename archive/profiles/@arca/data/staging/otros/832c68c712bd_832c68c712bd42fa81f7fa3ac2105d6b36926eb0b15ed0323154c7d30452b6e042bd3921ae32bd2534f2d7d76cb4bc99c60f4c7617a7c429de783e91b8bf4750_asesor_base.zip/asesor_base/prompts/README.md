Prompts base, plantillas y scripts de interacción para humanos o IA.
Dejar aquí todos los ejemplos o templates clave.
