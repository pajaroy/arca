# Asesor Base IA – Estructura

Este directorio es el entorno base para cualquier asesor IA avanzado dentro de ALMA_RESIST.
Contiene toda la documentación, contexto, memoria viva, bitácoras y herramientas necesarias para gobernanza y trazabilidad institucional.
Clonar esta estructura para cada nuevo asesor, ajustando sólo lo necesario según rol y responsable.
