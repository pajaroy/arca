# Changelog del Asesor

- [YYYY-MM-DD] Versión inicial.
