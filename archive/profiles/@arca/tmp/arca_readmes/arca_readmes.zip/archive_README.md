# archive

📦 Almacenamiento histórico de datos y copias.
Contiene:
- `backup/`: copias de seguridad
- `history/`: historial de versiones
- `snapshots/`: estados del sistema en un momento dado.
