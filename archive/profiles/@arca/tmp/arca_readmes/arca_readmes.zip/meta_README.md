# meta

📐 Esquemas, definiciones y metadatos globales.
Incluye:
- `schemas/`: definiciones de tablas y estructuras.
- `schema.sql` y `schema.yaml`: definiciones de base de datos.
