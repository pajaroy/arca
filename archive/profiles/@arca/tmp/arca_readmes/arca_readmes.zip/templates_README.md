# templates

🗂️ Plantillas base para metadatos, módulos y configuraciones.
Incluye ejemplos y formatos estándar para reutilizar.
