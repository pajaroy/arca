# modules

🧩 Módulos funcionales y agentes.
Cada carpeta representa un bloque de trabajo independiente.
Ejemplos: `13cc/`, `data/`.
