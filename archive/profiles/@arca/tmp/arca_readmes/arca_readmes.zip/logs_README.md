# logs

📝 Registros de ejecución y auditoría.
Incluye logs en formato `.csv` y notas de eventos importantes.
