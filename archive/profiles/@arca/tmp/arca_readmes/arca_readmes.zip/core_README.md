# core

🧠 Motor central del sistema.
Incluye:
- `ml/`: algoritmos de Machine Learning y RAG.
- `notebook/`: análisis exploratorios.
- `script/`: scripts de automatización.
- `test/`: pruebas unitarias.
- `util/`: utilidades compartidas.
