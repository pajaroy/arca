# database

🗄️ Almacenamiento persistente del sistema.
Incluye:
- `arca.db`: base de datos principal.
- Índices vectoriales, esquemas y metadatos persistentes.
