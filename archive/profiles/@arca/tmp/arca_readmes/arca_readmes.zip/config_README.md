# config

⚙️ Configuraciones globales y específicas por módulo.
Incluye archivos `.yaml` y otras configuraciones del sistema.
