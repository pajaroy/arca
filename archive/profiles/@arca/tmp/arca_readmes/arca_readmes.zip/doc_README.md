# doc

📚 Documentación interna y registros de investigación.
Incluye subcarpetas de documentación técnica y bitácoras.
